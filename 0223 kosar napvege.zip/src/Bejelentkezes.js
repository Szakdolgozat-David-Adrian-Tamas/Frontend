import { BrowserRouter, createBrowserRouter, json, NavLink, Route, Router, useNavigate } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";
import Regisztracio from "./Regisztracio";
import { Routes } from "react-router-dom";
import { sha256 } from "js-sha256";
import { useParams } from "react-router-dom";
import React from "react";

export default function Bejelentkezes(props) {
  const [isClicked, setClicked] = useState(true);
  
  const navigate = useNavigate();
  var sha256 = require('js-sha256');
  let felhasznaloNev = "";
  let Jelszo = "";

  
  if(isClicked){
    
    return (
      <form
        onSubmit={(e) => {
        e.preventDefault(); 
        (async () => {
            try {
              axios.post(process.env.REACT_APP_BACKEND_URL+`/Login/SaltRequest/${e.target.elements.felhasznaloNev?.value}`, {
                   felhasznaloNev : e.target.elements.felhasznaloNev?.value,
                   Jelszo : e.target.elements.HASH?.value
               })
               .then((response)=>{
                 console.log(response.data);
                 let lekertSalt = response.data;
                 let id = e.target.elements.Id?.value;
                 let tmpHash = sha256(Jelszo + lekertSalt).toString();
                 let url = process.env.REACT_APP_BACKEND_URL+`/Login?FelhasznaloNev=${e.target.elements.felhasznaloNev?.value}&tmpHash=${tmpHash}`
                 axios
                 .post(url, {
                   inputFelhasznaloNev : e.target.elements.felhasznaloNev?.value,
                   inputJelszo : e.target.elements.HASH?.value
                 })
                 .then((response) => {
                   if (response.status == 200) {

                       alert(
                         `Sikeres bejelentkezés: ${e.target.felhasznaloNev?.value}`
                       );
                      
                       console.log(e.target.elements);
                       navigate(`/felhasznalofiok/${e.target.elements.felhasznaloNev?.value}`)

                   } else {
                     alert(response.data, "Sikertelen bejelentkezés");
                   }
                 })
               })
             } catch (err) {
               alert(err + ": Sikertelen bejelentkezés");
             }
          
        })();
          
      }}  
      >

      <div className='bejelentkezesDiv'>
            <ul className="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
  </ul>
  <div className="tab-content">
    <div className="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">

        <div className="form-outline mb-4">
          <input type="text" id="loginName" name="felhasznaloNev" className="form-control" />
          <label className="form-label" htmlFor="loginName">Felhasználónév</label>
        </div>
        <div className="form-outline mb-4">
          <input type="password" id="loginPassword" name="Jelszo" className="form-control" />
          <label className="form-label" htmlFor="loginPassword">Jelszó</label>
        </div>
  
        <div className="row mb-4">
          <div className="col-md-6 d-flex justify-content-center">
  
            <div className="form-check mb-3 mb-md-0">
              <input className="form-check-input" type="checkbox" value="" id="loginCheck" />
              <label className="form-check-label" htmlFor="loginCheck"> Emlékezz rám! </label>
            </div>
          </div>
          <button type="submit" className="btn btn-primary btn-block mb-4">Belépés</button>
          <div className="col-md-6 d-flex justify-content-center">
            <a href="#!">Elfelejtetted a jelszavad?</a>
          </div>
        </div>
       
        <div className="text-center">
        <p>Nincs fiókod?</p>
        <NavLink to={`/regisztracio`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
                <span className="nav-link">Regisztrálj!</span>
              </NavLink>

          
        </div>
    </div>
    
  </div>
  <Routes>
      <Route path="/regisztracio" element={<Regisztracio/>}/>
      </Routes>
      </div>
      </form>
    )
  }

 
}
