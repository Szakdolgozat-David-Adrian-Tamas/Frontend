import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import Jateklista from './Jateklista';
import Jatekakcio from './Jatekakcio';
import Bejelentkezes from './Bejelentkezes';
import Informaciok from './Informaciok';
import images from './DAT.webshop.jpg';
import './styles.css';
import Kezdolap from './Kezdolap';
import { Egyjatek } from './Egyjatek';

import Akciokaland from './kategoriak/Akciokaland';
import Rpg from './kategoriak/Rpg';
import Racing from './kategoriak/Racing';
import Sport from './kategoriak/Sport';
import Shooter from './kategoriak/Shooter';
import Akcioszerepjatek from './kategoriak/Akcioszerepjatek';
import Regisztracio from './Regisztracio';
import FelhasznaloFiok from './FelhasznaloFiok';
import Kijelentkezes from './Kijelentkezes';

function App() {
  const [open, setOpen] = React.useState(false);

  const handleOpen = () => {
    setOpen(!open);
    const handleMenuOne = () => {
      // do something
      setOpen(false);
    };
  
    const handleMenuTwo = () => {
      // do something
      setOpen(false);
    };
 
  };
  return (
    <BrowserRouter>
    <div className='nagyDiv'>
    <nav className="navbar navbar-expand-sm navbar-dark bg-dark">
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav">
          <img className='logo' src={images} alt='imgf' ></img>
          <li className="nav-item">
            <NavLink to={`/`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")} end>
              <span className="nav-link">Kezdőlap</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/osszesjatek`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")} end>
              <span className="nav-link">Összes játék</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
                    <div className="dropdown">
              <button onClick={handleOpen} className="nav-link btn btn-secondary" id='dropdownButton'>Kategóriák</button>
              {open ? (
                <ul className="menu">
                  <li className="menu-item">
                  <NavLink  to={`/akciokaland`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Akció-Kaland</button></NavLink>
                    
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/rpg`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>RPG</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/racing`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Racing</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/sport`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Sport</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/shooter`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Shooter</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/akcio-szerepjatek`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Akció-Szerepjáték</button></NavLink>
                  </li>
                </ul>
              ) : null}
            </div>

            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/bejelentkezes`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Bejelentkezés</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/akciok`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Akciók</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/rolunk`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Információk rólunk</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/felhasznalofiok/:felhasznaloNev`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Saját fiók</span>
            </NavLink>
          </li>
        </ul>
      </div>
    </nav>
    </div>
    <Routes>
        <Route path="/" element={<Kezdolap/>}/>
        <Route path="/osszesjatek" element={<Jateklista/>}/>
        <Route path="/jatek/:id" element={<Egyjatek/>} />
        <Route path="/akciok" element={<Jatekakcio/>} />
        <Route path="/bejelentkezes/*" element={<Bejelentkezes/>}/>
        <Route path="/rolunk" element={<Informaciok/>}/>
        <Route path="/akciokaland" element={<Akciokaland/>}/>
        <Route path="/rpg" element={<Rpg/>}/>
        <Route path="/racing" element={<Racing/>}/>
        <Route path="/sport" element={<Sport/>}/>
        <Route path="/shooter" element={<Shooter/>}/>
        <Route path="/akcio-szerepjatek" element={<Akcioszerepjatek/>}/>
        <Route path="/regisztracio" element={<Regisztracio/>}/>
        <Route path="/felhasznalofiok/:felhasznaloNev" element={<FelhasznaloFiok/>}/>
        <Route path="/kijelentkezes" element={<Kijelentkezes/>}/>
    </Routes>
    </BrowserRouter>

  );
}


export default App;
