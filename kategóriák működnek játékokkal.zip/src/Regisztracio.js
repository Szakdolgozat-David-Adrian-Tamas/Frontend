import React from 'react'

export default function Regisztracio() {
  return (
    <div>
      
    </div>
  )
}
