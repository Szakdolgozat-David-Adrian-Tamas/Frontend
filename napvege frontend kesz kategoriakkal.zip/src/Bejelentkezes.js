import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login } from './Belepeskezelo';

export default function Bejelentkezes() {
  const [isLoginPending, setLoginPending] = useState(false);
  const navigate = useNavigate();

  function loginFormSubmit(e) {
    e.preventDefault();
    setLoginPending(true);
    login(e.target.elements.email.value, e.target.elements.password.value)
      .then(() => {
        setLoginPending(false);
        navigate("/osszes-szallas");
      })
      .catch((err) => {
        alert("Helytelen bejelentkezési adatok, kérjük próbáld újra!");
        setLoginPending(false);
      });
  }

  if (isLoginPending) {
    return (
      <div className="center-item">
        <div className="spinner-border text-danger"></div>
      </div>
    );
  }
  return (
    <div className='bejelentkezesDiv'>
          <ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
</ul>
<div class="tab-content">
  <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
    <form>

      <div class="form-outline mb-4">
        <input type="email" id="loginName" class="form-control" />
        <label class="form-label" for="loginName">Felhasználónév</label>
      </div>

      <div class="form-outline mb-4">
        <input type="password" id="loginPassword" class="form-control" />
        <label class="form-label" for="loginPassword">Jelszó</label>
      </div>

      <div class="row mb-4">
        <div class="col-md-6 d-flex justify-content-center">

          <div class="form-check mb-3 mb-md-0">
            <input class="form-check-input" type="checkbox" value="" id="loginCheck" checked />
            <label class="form-check-label" for="loginCheck"> Emlékezz rám! </label>
          </div>
        </div>

        <div class="col-md-6 d-flex justify-content-center">

          <a href="#!">Elfelejtetted a jelszavad?</a>
        </div>
      </div>

      <button type="submit" class="btn btn-primary btn-block mb-4">Belépés</button>

      <div class="text-center">
        <p>Nincs fiókod? <a href="#!">Regisztrálj</a></p>
      </div>
    </form>
  </div>
  <div class="tab-pane fade" id="pills-register" role="tabpanel" aria-labelledby="tab-register">
    <form>
      <div class="text-center mb-3">
        <p>Sign up with:</p>
        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-facebook-f"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-google"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-twitter"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-github"></i>
        </button>
      </div>

      <p class="text-center">or:</p>

      <div class="form-outline mb-4">
        <input type="text" id="registerName" class="form-control" />
        <label class="form-label" for="registerName">Name</label>
      </div>

      <div class="form-outline mb-4">
        <input type="text" id="registerUsername" class="form-control" />
        <label class="form-label" for="registerUsername">Username</label>
      </div>

      <div class="form-outline mb-4">
        <input type="email" id="registerEmail" class="form-control" />
        <label class="form-label" for="registerEmail">Email</label>
      </div>

      <div class="form-outline mb-4">
        <input type="password" id="registerPassword" class="form-control" />
        <label class="form-label" for="registerPassword">Password</label>
      </div>

      <div class="form-outline mb-4">
        <input type="password" id="registerRepeatPassword" class="form-control" />
        <label class="form-label" for="registerRepeatPassword">Repeat password</label>
      </div>
      <div class="form-check d-flex justify-content-center mb-4">
        <input class="form-check-input me-2" type="checkbox" value="" id="registerCheck" checked
          aria-describedby="registerCheckHelpText" />
        <label class="form-check-label" for="registerCheck">
          I have read and agree to the terms
        </label>
      </div>
      <button type="submit" class="btn btn-primary btn-block mb-3">Sign in</button>
    </form>
  </div>
</div>
    </div>


  )
}
