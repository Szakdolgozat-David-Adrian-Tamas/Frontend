import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import Jateklista from './Jateklista';
import Jatekakcio from './Jatekakcio';
import Jatekkategoria from './Jatekkategoria';
import Regisztracio from './Regisztracio';
import Bejelentkezes from './Bejelentkezes';
import Informaciok from './Informaciok';
import images from './DAT.webshop.jpg';
import './styles.css';
import { Dropdown } from 'bootstrap';
import Kezdolap from './Kezdolap';
import { Egyjatek } from './Egyjatek';

function App() {
  return (
    <BrowserRouter>
    <div className='nagyDiv'>
    <nav className="navbar navbar-expand-sm navbar-dark bg-dark">
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav">
          <img className='logo' src={images} alt='imgf' ></img>
          <li className="nav-item">
            <NavLink to={`/`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")} end>
              <span className="nav-link">Kezdőlap</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/osszesjatek`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")} end>
              <span className="nav-link">Összes játék</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/akciok`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Akciók</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/kategoriak`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Kategóriák</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/regisztracio`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Regisztráció</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/bejelentkezes`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Bejelentkezés</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/rolunk`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Információk rólunk</span>
            </NavLink>
          </li>
        </ul>
      </div>
    </nav>
    </div>
    <Routes>
        <Route path="/" element={<Kezdolap/>}/>
        <Route path="/osszesjatek" element={<Jateklista/>}/>
        <Route path="/jatek/:id" element={<Egyjatek/>} />
        <Route path="/akciok" element={<Jatekakcio/>} />
        <Route path="/kategoriak" element={<Jatekkategoria/>}/>
        <Route path="/regisztracio" element={<Regisztracio/>}/>
        <Route path="/bejelentkezes" element={<Bejelentkezes/>}/>
        <Route path="/rolunk" element={<Informaciok/>}/>
    </Routes>
    </BrowserRouter>

  );
}


export default App;
