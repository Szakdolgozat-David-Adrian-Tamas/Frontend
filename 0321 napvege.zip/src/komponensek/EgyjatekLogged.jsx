import axios from "axios";
import { React, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { FaCartPlus } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import {FaCartArrowDown} from "react-icons/fa";
import { Route, Routes } from "react-router-dom";
import Kosar from "./Kosar";
import Card from 'react-bootstrap/Card';
import '../../src/App.css';
import { Navbar } from "../navbar";
import '../egyjatek.scss';
import { NavbarLogged } from "./NavbarLogged";

export function EgyjatekLogged(props) {
    //const id = props.match.params.hangszerId;
    const param = useParams();
    const id = param.id;
    const [jatek, setGame] = useState([{}]);
    const [isPending, setPending] = useState(false);
    const [cart, setCart] = useState(false);
    console.log(param);
    const navigate = useNavigate();

    function cartAdded(){
      if(setCart(!cart)){
        navigate('/kosar');
      }
    }
    
    useEffect(() => {
        setPending(true);
          (async () => {
            try {
              const games = await axios.get(process.env.REACT_APP_BACKEND_URL+`/api/jatek/${id}`);
              setGame(games.data);
              console.log(games.data[0].kep);
            } catch (err) {
              console.log(err);
            } finally {
              setPending(false);
            }
          })();
      }, []);

    return (
      <>
      <NavbarLogged/>
      <div className="container mt-5">
  <div className="row">
    <div className="col-12">
      <article className="blog-card">
        <div className="blog-card__background">
          <div className="card__background--wrapper">
            <div className="card__background--main" src={{backgroundImage: (`data:image/jpg;base64,${jatek[0].kep}`)}}>
            <img
                  className="img-fluid rounded"
                  src={`data:image/jpg;base64,${jatek[0].kep}`}
                />
              <div className="card__background--layer"></div>
            </div>
          </div>
        </div>
        <div className="blog-card__head">
          <span className="date__box">
            <span className="date__day">{jatek[0].megjelenes}</span>
          </span>
        </div>
        <div className="blog-card__info">
          <h5>{jatek[0].nev}</h5>
          <p>{jatek[0].leiras}</p>
          <a href="#" className="btn btn--with-icon"><i className="btn-icon fa fa-long-arrow-right"></i>Olvass többet</a>
        </div>
      </article>
    </div>
  </div>
</div>

<section className="detail-page">
  <div className="container mt-5">
    
  </div>
</section>

      </>
       
      );
  }