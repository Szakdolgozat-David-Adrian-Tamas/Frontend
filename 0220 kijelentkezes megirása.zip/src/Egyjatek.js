import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export function Egyjatek(props) {
    //const id = props.match.params.hangszerId;
    const param = useParams();
    const id = param.id;
    const [jatek, setGame] = useState([{}]);
    const [isPending, setPending] = useState(false);
    console.log(param);
    
    useEffect(() => {
        setPending(true);
          (async () => {
            try {
              const games = await axios.get(process.env.REACT_APP_BACKEND_URL+`/api/jatek/${id}`);
              setGame(games.data);
              console.log(games.data[0].kep);
            } catch (err) {
              console.log(err);
            } finally {
              setPending(false);
            }
          })();
      }, []);

    return (
        <div className="p-5  m-auto text-center content bg-lavender">
          {isPending || jatek.id ? (
            <div className="spinner-border"></div>
          ) : (
            <div className="card p-3">
              <div className="card-body">
                <h5 className="card-title">{jatek[0].nev}</h5>
                <div className="lead">{jatek[0].kategoria}</div>
                <p>Ár:{jatek[0].ar} Ft</p>
                <p>Rövid ismertető: {jatek[0].leiras}</p>
                <img
                  className="img-fluid rounded"
                  style={{ maxHeight: "500px" }}
                  src={`data:image/jpg;base64,${jatek[0].kep}`}
                />
                <h5>Megjelenési dátum: {jatek[0].megjelenes}</h5>

              </div>
            </div>
          )}
        </div>
      );
  }