import React from 'react'
import axios from 'axios'

export default function Kijelentkezes() {
  return (
    <form
    onSubmit={(d)=>{
      d.preventDefault();
      (async()=>{
        try{
          axios.post(process.env.REACT_APP_BACKEND_URL+`/Logout/SaltRequest/`)
        }catch(err){
          alert(err)
        }
      })();
    }}
    >


    <div>
      <button type='submit' className='btn btn-secondary'>Kijelentkezés</button>
    </div>
    </form>
  )
}
