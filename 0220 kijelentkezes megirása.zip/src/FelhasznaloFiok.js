import React from 'react';
import axios from "axios";
import { useParams } from 'react-router-dom';
import { useEffect, useState } from "react";
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import Kijelentkezes from './Kijelentkezes';

function FelhasznaloFiok() {
  const param = useParams();
  const felhasznaloBelepes = param.felhasznaloNev;
  const [felhasznalo, setFelhasznalo] = useState([{}]);
  const [isPending, setPending] = useState(false);


  console.log(param);
  
  useEffect(() => {
      setPending(true);
        (async () => {
          try {
            const user = await axios.get(process.env.REACT_APP_BACKEND_URL+`/api/felhasznalo/${felhasznaloBelepes}`);
            setFelhasznalo(user.data);
            console.log(user.data);
          } catch (err) {
            console.log(err);
          } finally {
            setPending(false);
          }
        })();
    }, []);

  return (
      <div className="p-5  m-auto text-center content bg-lavender">
        {isPending || !felhasznalo[0].felhasznaloNev ? (
          <div className="spinner-border"></div>
        ) : (
          <div className="card p-3">
            <div className="card-body">
              Felhasználónév: <h5 className="card-title">{felhasznalo[0].felhasznaloNev}</h5><hr></hr>
              Teljes név: <div className="lead">{felhasznalo[0].teljesNev}</div><hr></hr>
              E-mail cím: <h5>{felhasznalo[0].email}</h5>
            </div>
          </div>
        )}
        <NavLink to={`/kijelentkezes`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
                <span className="nav-link">Kijelentkezés!</span>
              </NavLink>
              <Routes>
      <Route path="/kijelentkezes" element={<Kijelentkezes/>}/>
      </Routes>
      </div>  
      
    );
}

export default FelhasznaloFiok;
