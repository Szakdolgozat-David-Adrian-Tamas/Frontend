import axios from 'axios';
import React, { useEffect } from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Regisztracio(props) {
    const navigate = useNavigate();
    const [generateSalt, setGenerateSalt] = useState();
    //const [adatok, setAdatok] = useState([{}]);
    //const [isFetchPending, setFetchPending] = useState(false);
    useEffect(()=>{
        generateSalt((lengt)=>{
            var text = "";
            var possible =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for (var i = 0; i < lengt; i++)
              text += possible.charAt(Math.floor(Math.random() * possible.length));
            return text;
         }) 
    },[])
    
      
  return (
    <div className="p-5 content bg-whitesmoke text-center">
    <h2>Új felhasználó</h2>
    <form 
      onSubmit={(e) => {
        e.preventDefault();
        (async () => {
          try {
           await axios.post(process.env.REACT_APP_BACKEND_URL+"/Registry", {
                Id: e.target.elements.Id?.value,
                FelhasznaloNev: e.target.elements.FelhasznaloNev?.value,
                TeljesNev: e.target.elements.TeljesNev?.value,
                SALT: e.target.elements.SALT?.value,
                HASH: e.target.elements.HASH?.value,
                Email: e.target.elements.Email?.value,
                Key: e.target.elements.Key?.value
            }, );
            navigate('/bejelentkezes')
            console.log();
          } catch (err) {
            console.log(err);
          }
        })();
        
      }}
    >
    <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Id:</label>
        <div className="col-sm-9">
          <input type="text" name="Id" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Felhasználónév:</label>
        <div className="col-sm-9">
          <input type="text" name="FelhasznaloNev" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Teljes Név:</label>
        <div className="col-sm-9">
          <input type="text" name="FeljesNev" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Salt:</label>
        <div className="col-sm-9">
          <input type="text" name="SALT" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Hash:</label>
        <div className="col-sm-9">
          <input type="text" name="HASH" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Email:</label>
        <div className="col-sm-9">
          <input type="text" name="Email" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Key:</label>
        <div className="col-sm-9">
          <input type="text" name="Key" className="form-control" />
        </div>
      </div>
      <button type="submit" className="btn btn-success">
        Regisztráció:
      </button>
    </form>
  </div>
  )
}
