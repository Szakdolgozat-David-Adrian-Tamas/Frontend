import React from 'react'

export default function Jatekkategoria() {
  return (
    <div>
      
    </div>
  )
}
