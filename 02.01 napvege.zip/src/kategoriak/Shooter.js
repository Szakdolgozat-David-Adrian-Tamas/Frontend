import React from 'react'

export default function Shooter() {
  return (
    <div>
      
    </div>
  )
}
