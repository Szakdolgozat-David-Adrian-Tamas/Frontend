import React from 'react'
import axios from 'axios'
import { Navigate, useNavigate } from 'react-router-dom';

export default function Kijelentkezes() {
  const navigate = useNavigate();
  return (
    <form
    onSubmit={(d)=>{
      d.preventDefault();
      navigate("/");
      window.location.reload(true);
    }}
    >


    <div>
      <button type='submit' className='btn btn-secondary'>Kijelentkezés</button>
    </div>
    </form>
  )
}
