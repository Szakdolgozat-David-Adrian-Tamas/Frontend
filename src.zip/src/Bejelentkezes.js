import { NavLink, useNavigate } from "react-router-dom";
import CryptoJS from "crypto-js";
import axios from "axios";
import { useEffect, useState } from "react";

export default function Bejelentkezes() {
  const [isLoginPending, setLoginPending] = useState(false);
  const navigate = useNavigate();


  
  if (isLoginPending) {
    return (
      <div className="center-item" >
        <div className="spinner-border text-danger"></div>
      </div>
    );
  }
  return (
    <div className='bejelentkezesDiv'>
          <ul className="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
</ul>
<div className="tab-content">
  <div className="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
    <form>

      <div className="form-outline mb-4">
        <input type="text" id="loginName" className="form-control" />
        <label className="form-label" htmlFor="loginName">Felhasználónév</label>
      </div>

      <div className="form-outline mb-4">
        <input type="password" id="loginPassword" className="form-control" />
        <label className="form-label" htmlFor="loginPassword">Jelszó</label>
      </div>

      <div className="row mb-4">
        <div className="col-md-6 d-flex justify-content-center">

          <div className="form-check mb-3 mb-md-0">
            <input className="form-check-input" type="checkbox" value="" id="loginCheck" />
            <label className="form-check-label" htmlFor="loginCheck"> Emlékezz rám! </label>
          </div>
        </div>

        <div className="col-md-6 d-flex justify-content-center">

          <a href="#!">Elfelejtetted a jelszavad?</a>
        </div>
      </div>

      <button type="submit" className="btn btn-primary btn-block mb-4">Belépés</button>

      <div className="text-center">
        <p>Nincs fiókod? <a href="#!">Regisztrálj</a></p>
      </div>
    </form>
  </div>

</div>
    </div>


  )
}
