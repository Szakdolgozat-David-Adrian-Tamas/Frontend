import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import './App.css';
import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import axios from 'axios';
import bloodborne from './bloodborne.jpg';
import gow from './gow.jpg';
import hgl from './hgl.jpg';
import needforspeed from './needforspeed.jpg';
import nier from './nier.jpg';
import sekiro from './sekiro.jpg';
import tsushima from './tsushima.jpg';


export default function Jateklista() {
  const images = [
    bloodborne,
    gow,
    hgl,
    needforspeed,
    nier,
    sekiro,
    tsushima
];
    const [game, setGame] = useState([]);
    const [isFetchPending, setFetchPending] = useState(false);
    
    useEffect(() => {
        setFetchPending(true);
        (async() => {
            try {
                const games = await axios.get("https://localhost:5001/api/jatek", );
                setGame(games.data);
                console.log(game);
            } catch (err) {
                console.log(err);
            } finally {
                setFetchPending(false);
            }
        })();
      }, []);
    
    return (
        <div className="p-5  m-auto text-center content bg-ivory">
          {isFetchPending ? (
            <div className="spinner-border"></div>
          ) : (
            <div>
              <h2>Játékaink:</h2>
              {game.map((game) => (
                <NavLink key={game.id} to={"/jatek/" + game.id}>
                  <div className="card col-sm-3 d-inline-block m-1 p-2">
                    <h3 className="text-muted">{game.nev}</h3>
                    <h4 className="text-dark">{game.ar}Ft</h4>
                    </div>
                  </NavLink>
              ))}
            </div>
          )}
        </div>
      );
}
