import React from 'react'

export default function Informaciok() {
  return (
    <div>
      
    </div>
  )
}
