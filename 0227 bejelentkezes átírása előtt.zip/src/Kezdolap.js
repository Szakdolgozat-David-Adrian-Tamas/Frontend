import React from 'react'
import bloodborne from './bloodborne.jpg';
import gow from './gow.jpg';
import hgl from './hgl.jpg';
import needforspeed from './needforspeed.jpg';
import nier from './nier.jpg';
import sekiro from './sekiro.jpg';
import tsushima from './tsushima.jpg'
import 'bootstrap/dist/css/bootstrap.css';
import {Helmet} from 'react-helmet';
import 'react-slideshow-image/dist/styles.css';
import { Slide } from 'react-slideshow-image';

export default function Kezdolap() {
    const images = [
        bloodborne,
        gow,
        hgl,
        needforspeed,
        nier,
        sekiro,
        tsushima
    ];

    return (

        <div className='slideClass'>
                             <Helmet>
        <style>{'body { background-color: black; }'}</style>
    </Helmet>
                 <Slide>

<div className="each-slide-effect">
    <div style={{ 'backgroundImage': `url(${images[0]})` }}>
    </div>
</div>
<div className="each-slide-effect">
    <div style={{ 'backgroundImage': `url(${images[1]})` }}>
    </div>
</div>
<div className="each-slide-effect">
    <div style={{ 'backgroundImage': `url(${images[2]})` }}>
    </div>
</div>
<div className="each-slide-effect">
    <div style={{ 'backgroundImage': `url(${images[3]})` }}>
    </div>
</div>
<div className="each-slide-effect">
    <div style={{ 'backgroundImage': `url(${images[4]})` }}>
    </div>
</div>
<div className="each-slide-effect">
    <div style={{ 'backgroundImage': `url(${images[5]})` }}>
    </div>
</div>
<div className="each-slide-effect">
    <div style={{ 'backgroundImage': `url(${images[6]})` }}>
    </div>
</div>
</Slide>
        </div>
       
    );

};

   