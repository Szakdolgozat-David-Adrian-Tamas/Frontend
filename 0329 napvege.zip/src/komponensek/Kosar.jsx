import axios from "axios";
import { React, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import '../../src/App.css';
import '../egyjatek.scss';
import { NavbarLogged } from "./NavbarLogged";
import { NavLink } from "react-router-dom";

export default function Kosar() {
  const [isPending, setPending] = useState(false);
    const [cart, setCart] = useState([]);
    const navigate = useNavigate();


  useEffect(() => {
    setPending(true);
      (async () => {
        try{
            const cart = await axios.get("https://localhost:5001/kosar/1?id=1")
            setCart(cart.data);
            console.log(cart);
        }catch(error){
          console.log(error);
        }finally{
          setPending(false);
        }
      })();
}, []);

  return (
    <>
      <NavbarLogged/>
      <div className="p-5  m-auto text-center content bg-ivory">
        {isPending ? (
          <div className="spinner-border"></div>
        ) : (
          <div>
            <h2 className='jateknevszin'>Kosarad tartalma:</h2>
            {cart.map((cart) => (
              <NavLink key={cart.id} to={"/jatek/" + cart.id}>
                <figure>
                  <div className='jateknev'>
  <figcaption><h3 id='jateknev' className="text-muted">{cart.nev}</h3></figcaption>
  <figcaption><h4 id='jateknev' className="text-dark">{cart.kategoria}</h4></figcaption>
  <figcaption><h6 id='jateknev' className="text-dark">{cart.leiras}</h6></figcaption>
                  </div>
  <figure>
    

  <figcaption><h4 className="text-dark">{cart.ar}Ft</h4></figcaption>
  
                  <img height={"300px"} width={"325px"} src={`data:image/jpg;base64,${cart.kep}`}></img>

                </figure>
                
</figure>
                
                </NavLink>
            ))}
          </div>
        )}
      </div>
    </>
    );
}
  

