import axios from 'axios';
import { sha256 } from 'js-sha256';
import React, { useEffect } from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Regisztracio(props) {
    const navigate = useNavigate();
    const [generateSalt, setGenerateSalt] = useState();
    const [generateHash, setGenerateHash] = useState();
    var sha256 = require('js-sha256');
    //const [adatok, setAdatok] = useState([{}]);
    //const [isFetchPending, setFetchPending] = useState(false);
        function Saltgeneralas(lengt){
            var text = "";
            var possible =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for (var i = 0; i < lengt; i++)
              text += possible.charAt(Math.floor(Math.random() * possible.length));
            console.log(text);
            return text;
         }
         console.log();
    
      
  return (
    <div className="p-5 content bg-whitesmoke text-center">
    <h2>Új felhasználó</h2>
    <form 
      onSubmit={(e) => {
        e.preventDefault(); 
        (async () => {
          try {
           axios.post(process.env.REACT_APP_BACKEND_URL+"/Registry", {
                Id: e.target.elements.Id?.value,
                FelhasznaloNev: e.target.elements.FelhasznaloNev?.value,
                TeljesNev: e.target.elements.TeljesNev?.value,
                SALT: Saltgeneralas(64),
                HASH: sha256(''),
                Email: e.target.elements.Email?.value,
                Key: "",
            }, );
            console.log(e);
            navigate('/bejelentkezes')
          } catch (err) {
            console.log(err);
          }
        })();
          
      }}  
    > 
      <div className="form-group row pb-3"> 
        <label className="col-sm-3 col-form-label">Felhasználónév:</label>  
        <div className="col-sm-9">  
          <input type="text" name="FelhasznaloNev" className="form-control" />  
        </div>  
      </div>  
      <div className="form-group row pb-3"> 
        <label className="col-sm-3 col-form-label">Teljes Név:</label>
        <div className="col-sm-9">
          <input type="text" name="TeljesNev" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Email:</label>
        <div className="col-sm-9">
          <input type="text" name="Email" className="form-control" />
        </div>
      </div>
      <div className="form-group row pb-3">
        <label className="col-sm-3 col-form-label">Jelszó:</label>
        <div className="col-sm-9">
          <input type="text" name="SALT"  className="form-control" />
        </div>
      </div>
      <button type="submit" className="btn btn-success">
        Regisztráció
      </button>
    </form>
  </div>
  )
}
