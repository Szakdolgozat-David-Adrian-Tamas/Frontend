import { NavLink, Route, useNavigate } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";
import Regisztracio from "./Regisztracio";
import { Routes } from "react-router-dom";
import { sha256 } from "js-sha256";

export default function Bejelentkezes() {
  const [isClicked, setClicked] = useState(true);

  const navigate = useNavigate();
  var sha256 = require('js-sha256');
  let FelhasznaloNev = "";
  let Jelszo = "";

  function loginClick(){
      try {
        axios.post(process.env.REACT_APP_BACKEND_URL+`/Login/SaltRequest/${FelhasznaloNev}`,{
          inputFelhasznaloNev : FelhasznaloNev,
          inputJelszo : Jelszo,
        })
        .then((response)=>{
         let lekertSalt = response.data;
         let tmpHash = sha256(Jelszo + lekertSalt).toString();
         console.log(response);
         let url = process.env.REACT_APP_BACKEND_URL+`/Login?FelhasznaloNev=${FelhasznaloNev}&tmpHash=${tmpHash}`
        axios
        .post(url)
        .then((response) => {
          if (response.status == 200) {
              console.log(
                `Sikeres bejelentkezés: ${FelhasznaloNev}`
              );
              //navigate('/')
          } else {
            console.log("Sikertelen bejelentkezés");
          }
        })
        })
        .catch((error) => {
          console.log(error);
        });
       }
       catch(error){
        console.log(error);
        if (error.response.status == 400) {
          console.log(error.response.data);
        } else {
          alert("Üres a felhasználónév!");
        }
      };
    

   
  }


  if(isClicked){
    
    return (

      <div className='bejelentkezesDiv'>
            <ul className="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
  </ul>
  <div className="tab-content">
    <div className="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
  
        <div className="form-outline mb-4">
          <input type="text" id="loginName" name="inputFelhasznaloNev" className="form-control" />
          <label className="form-label" htmlFor="loginName">Felhasználónév</label>
        </div>
        <div className="form-outline mb-4">
          <input type="password" id="loginPassword" name="inputJelszo" className="form-control" />
          <label className="form-label" htmlFor="loginPassword">Jelszó</label>
        </div>
  
        <div className="row mb-4">
          <div className="col-md-6 d-flex justify-content-center">
  
            <div className="form-check mb-3 mb-md-0">
              <input className="form-check-input" type="checkbox" value="" id="loginCheck" />
              <label className="form-check-label" htmlFor="loginCheck"> Emlékezz rám! </label>
            </div>
          </div>
          <button onClick={loginClick} className="btn btn-primary btn-block mb-4">Belépés</button>
          <div className="col-md-6 d-flex justify-content-center">
            <a href="#!">Elfelejtetted a jelszavad?</a>
          </div>
        </div>
       
        <div className="text-center">
        <p>Nincs fiókod?</p>
        <NavLink to={`/regisztracio`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
                <span className="nav-link">Regisztrálj!</span>
              </NavLink>
      
        </div>
    </div>
  
  </div>
  <Routes>
      <Route path="/regisztracio" element={<Regisztracio/>}/>
      </Routes>
      </div>
      
    )
  }

 
}
