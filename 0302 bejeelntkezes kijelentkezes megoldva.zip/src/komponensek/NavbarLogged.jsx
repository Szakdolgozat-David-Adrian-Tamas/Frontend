import React from 'react'
import '../App.css';
import 'bootstrap/dist/css/bootstrap.css';
import { Router } from 'react-router-dom';
import { BrowserRouter, Navigate, NavLink, Route, Routes } from 'react-router-dom';
import images from '../komponensek/DAT.webshop.jpg';
import '../styles.css';
import {FaGamepad} from "react-icons/fa";
import {ShoppingCart} from 'phosphor-react'
export const NavbarLogged = () => {
    const [open, setOpen] = React.useState(false);
    const [clicked, setClicked] = React.useState(false);
    
    function linkClicked (){
      setClicked(!clicked);
    }
  
  
    const handleOpen = () => {
      setOpen(!open);
      const handleMenuOne = () => {
        // do something
        setOpen(false);
      };
    
      const handleMenuTwo = () => {
        // do something
        setOpen(false);
      };
   
    };
  return (
    <div className='nagyDiv'>
    <nav className="navbar navbar-expand-sm navbar-dark bg-dark">
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav">
          <img className='logo' src={images} alt='imgf' ></img>
          <li className="nav-item">
            <NavLink to={`/`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")} end>
              <span className="nav-link">Kezdőlap</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/osszesjatek`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")} end>
              <span className="nav-link"> Összes játék</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
                    <div className="dropdown">
              <button onClick={handleOpen} className="nav-link btn btn-secondary" id='dropdownButton'>Kategóriák</button>
              {open ? (
                <ul className="menu">
                  <li className="menu-item">
                  <NavLink  to={`/akciokaland`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Akció-Kaland</button></NavLink>
                    
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/rpg`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>RPG</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/racing`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Racing</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/sport`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Sport</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/shooter`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Shooter</button></NavLink>
                  </li>
                  <li className="menu-item">
                  <NavLink  to={`/akcio-szerepjatek`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}> <button>Akció-Szerepjáték</button></NavLink>
                  </li>
                </ul>
              ) : null}
            </div>
            </NavLink>
          </li>       

          <li className="nav-item">
           <NavLink to={`/`} className={({ isActive }) => "nav-link" + (isActive ? "active" : "")}>
            <button className="nav-link btn btn-danger">Kijelentkezés</button>
           </NavLink> 
          </li>
          
          <li className="nav-item">
            <NavLink to={`/rolunk`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Információk rólunk</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/kosar`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
            <ShoppingCart size={32}/>
            </NavLink>
          </li>

        </ul>
      </div>
    </nav>
    </div>
  )
}


