import axios from "axios";
import { React, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import '../../src/App.css';
import '../egyjatek.scss';
import { NavbarLogged } from "./NavbarLogged";
import { Bejelentkezes } from "./Bejelentkezes";
import CartFid from "../KosarFelhId";

export default function Kosar() {
  const [isPending, setPending] = useState(false);
    const [kosarVasarlo, setCart] = useState([]);
    const navigate = useNavigate();

    /*function KosarTorles(){
      setPending(true);
      (async () => {
        try {
          const cartGames = await axios.delete(process.env.REACT_APP_BACKEND_URL+`/kosar?id=3`)
    setCart(cartGames.data);
    console.log(cartGames.data);
      } catch (err) {
        console.log(err);
      } finally {
        setPending(false);
      }
    })();
    }*/

    useEffect(() => {
      
      console.log(kosarVasarlo);
      setPending(true);
        (async () => {
          try{
              const cart = await axios.get(`https://localhost:5001/kosar/${window.$userId}`)
              setCart(cart.data);
              console.log(cart);
          }catch(error){
            console.log(error);
          }finally{
            setPending(false);
          }
        })();
  }, []);

  return (
    <>
    
      <NavbarLogged/>
      <div className="p-5  m-auto text-center content bg-ivory">
        {isPending ? (
          <div className="spinner-border"></div>
        ) : (
          <div>
            <h2 className='jateknevszin'>Kosarad tartalma:</h2>
            {kosarVasarlo.map((kosarVasarlo) => (
              
              <>
              <button type="button" className="btn btn-danger">Törlés</button>
              <table className="table table-striped">
                <tbody>
                <tr>
                  <th>ID</th>
                  <th>Vásárló azonosító</th>
                  <th>Játék azonosító</th>
                  <th>Darabszám</th>
                </tr>
                
                <tr>
                  <td>{kosarVasarlo.id}</td>
                  <td>{kosarVasarlo.vasarloId}</td>
                  <td>{kosarVasarlo.jatekId}</td>
                  <td>{kosarVasarlo.darab}</td>
                </tr>
                </tbody>
                
              </table>
              
              </>
            ))}
          </div>
        )}
      </div>
    </>
    );
}
  

