import React from 'react'
import { useState } from 'react';
import axios from 'axios';
import { useEffect } from 'react';

export function UseridLekeres() {
    const [vasarloId, setVasarloId] = useState([]);
    useEffect(() => {
        (async () => {
          try {
            const kosarfid = await axios.get(process.env.REACT_APP_BACKEND_URL+`/api/felhasznalo`);
            setVasarloId(kosarfid.data);
            console.log(kosarfid.data);
          } catch (err) {
            console.log(err);
          } 
        })();
    }, []);
}
