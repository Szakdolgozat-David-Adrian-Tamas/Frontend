import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import Jateklista from './Jateklista';
import Jatekakcio from './Jatekakcio';
import Bejelentkezes from './Bejelentkezes';
import Informaciok from './Informaciok';
import images from './DAT.webshop.jpg';
import './styles.css';
import Kezdolap from './Kezdolap';
import { Egyjatek } from './Egyjatek';

import Akciokaland from './kategoriak/Akciokaland';
import Rpg from './kategoriak/Rpg';
import Racing from './kategoriak/Racing';
import Sport from './kategoriak/Sport';
import Shooter from './kategoriak/Shooter';
import Akcioszerepjatek from './kategoriak/Akcioszerepjatek';
import Regisztracio from './Regisztracio';

function FelhasznaloFiok() {
  const [open, setOpen] = React.useState(false);

  return (
    <div>bent vagy</div>
  );
}

export default FelhasznaloFiok;
